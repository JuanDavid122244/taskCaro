import Object as ot
import Animal as al
import Element as et
import Terrain as tn
import Interaction as itn
import matplotlib.pyplot as plt
import numpy as np
import random
elements=[]
def main():
    print('Project Terrain :)')
    path = 'terrain.csv'
    terrain = tn.Terrain(path)
    array_terrain = terrain.map
    ax = terrain.do_figure()

    create = Create_Objects(array_terrain,ax)

    create.star_elements(5,1,1)

   

    plt.title('Project Terrain', fontdict={'fontsize': 18})
    plt.show()




class Create_Objects:
    def __init__(self, array_terrain, ax):
        self.ax = ax
        self.array_terrain = array_terrain
        self.environment = {'Rock': 8, 'Flower': 4, 'Lotus': 2}

    def star_elements(self,num_rocks,num_flower,num_lotus): #create objects elements
        for i in range(num_rocks):
            print('info: Do Rock ',(i+1))
            environment  = self.find_environment(self.environment.get('Rock'))
            pos = random.choice(environment)
            print(pos)
            environment.remove(pos) # delete tuple for dont permit same place
            rock = et.Rock(pos)
            rock.drow(self.ax)



    def find_environment(self,num_env): # find the enviroment  
        tuples =[]
        for i in range(np.shape(self.array_terrain)[0]):
            for j in range(np.shape(self.array_terrain)[1]):              
                if self.array_terrain[i,j] == num_env:
                    tuples.append((i, j))
        return tuples
    



if __name__ == "__main__":
    main()

        