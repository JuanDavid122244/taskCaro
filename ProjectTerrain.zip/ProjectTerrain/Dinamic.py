import Object as ot
import Animal as al
import Element as et
import Terrain as tn
import Interaction as itn
import matplotlib.pyplot as plt
import numpy as np
import random

def main():

    print('Project Terrain :)')
    path = 'C:/Users/parrad/Downloads/ProjectTerrain/ProjectTerrain/terrain.csv'
    terrain = tn.Terrain(path)
    array_terrain = terrain.map
    ax = terrain.do_figure()

    create = Create_Objects(array_terrain,ax) #Create object type Create_Objects
    
    list_objects=create.start_elements(50,20,9)
    list_animal=create.start_animals(3,10,10,20)
    list_rain=create.rain()

    interaction = itn.Interaction(list_animal,list_objects,array_terrain,list_rain) #Create object type Interaction

    for i in range(35): #Generates the visual iteration

        is_rain = False
        if i > 5 and i < 10:
            is_rain = True

        interaction.drow_all(ax,is_rain)
        
        plt.imshow(array_terrain,cmap='terrain')
        plt.title(("Terrain ",i+1), fontsize="18")
        plt.pause(1)
        plt.cla() #Clear figure



class Create_Objects: #Class for Create all objects

    def __init__(self, array_terrain, ax):
        self.list_animals = []
        self.list_objects = []
        self.list_rain = []
        self.ax = ax
        self.array_terrain = array_terrain
        # environment = {'Rock': 8, 'Flower': 4, 'Lotus': 2, 'Bfly':1, 'Ant':10, 'Fish':0}


    def start_elements(self,num_rocks,num_flower,num_lotus): #create objects elements
        colors = ['blue','pink','purple']
        self.lotusposition = []

        environment  = self.find_environment(8)
        for i in range(num_rocks):
            print('info: Do Rock ',(i+1))
            
            pos = random.choice(environment)
            environment.remove(pos) # delete tuple for dont permit same place
            rock = et.Rock(pos)
            self.list_objects.append(rock)

        environment  = self.find_environment(4)
        for i in range(num_flower):
            print('info: Do flower', (i+1))
            color = random.choices(colors)
            pos = random.choice(environment)
            environment.remove(pos) # delete tuple for dont permit same place
            flower = et.Flower(color[0], (pos[0],pos[1]-1))
            self.list_objects.append(flower)

        environment  = self.find_environment(2)
        for i in range(num_lotus):
            print('info: Do lotus', (i+1))
            pos = random.choice(environment)
            self.lotusposition.append(pos)
            environment.remove(pos) # delete tuple for dont permit same place
            lotus = et.Lotus(pos)
            lotus.pos = (lotus.pos[0], lotus.pos[1])
            self.list_objects.append(lotus)
        
        return self.list_objects


    def start_animals(self,num_frog,num_bfly,num_ant,num_fish): #create objects animals
        colors = ['blue','pink','purple']

        lotus_start = self.lotusposition[:]
        for i in range(num_frog):
            print('info: Do frog ',(i+1))
            pos = random.choice(lotus_start)
            lotus_start.remove(pos) # delete tuple for dont permit same place
            frog = al.Frog(pos,self.lotusposition,('frog ',i))
            self.list_animals.append(frog)

        environment  = self.find_environment(1)
        for i in range(num_bfly):
            pos = random.choice(environment)
            environment.remove(pos) # delete tuple for dont permit same place
            color = random.choices(colors)
            bfly = al.Bfly(pos,color[0],('bfly ',i))
            print('info: Do Bfly ',(i+1),pos)
            self.list_animals.append(bfly)

        environment  = self.find_environment(10)
        for i in range(num_ant):
            print('info: Do ant ',(i+1))
            pos = random.choice(environment)
            environment.remove(pos) # delete tuple for dont permit same place
            ant = al.Ant(pos,('ant ',i))
            self.list_animals.append(ant)

        environment  = self.find_environment(0)
        for i in range(num_fish):
            print('info: Do fish ',(i+1))
            pos = random.choice(environment)
            color = random.choices(colors)
            environment.remove(pos) # delete tuple for dont permit same place
            fish = al.Fish(pos,color[0],('fish ',i))
            self.list_animals.append(fish)

        return self.list_animals


    def find_environment(self,num_env): # find the environment

        tuples =[]

        for i in range(np.shape(self.array_terrain)[0]):
            for j in range(np.shape(self.array_terrain)[1]):
                if self.array_terrain[i,j] == num_env:
                    tuples.append((j, i))

        return tuples
    

    def rain(self):

        for i in range(np.shape(self.array_terrain)[0]):
            if i%3 == 0:
                for j in range(np.shape(self.array_terrain)[1]):
                    if j%3 == 0:
                        pos = (j, i)
                        rain = et.Rain(pos)
                        self.list_rain.append(rain)
        
        return self.list_rain




if __name__ == "__main__": #Start to execute the main method
    main()

        