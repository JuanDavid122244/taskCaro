import numpy as np
import matplotlib.pyplot as plt
class Terrain:
    def __init__(self, path) :
        self.map = self.read_csv(path)
        

    def read_csv(self, path):
        try:
            file = open(path,'r')
            lines = file.readlines()
        except OSError as err:
            print('OS error:'+err)

        data=[]
        for list in lines:
            listInt = []
            for item in list.split(';'):
                listInt.append(int(item))

            data.append(listInt) 
        return np.array(data)
    
    def do_figure(self):
        print('info: Do figure')
        fig = plt.figure(figsize=(8,8))     
        plt.imshow(self.map, cmap='terrain')
        return fig.axes
        
     
        


