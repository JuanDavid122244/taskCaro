import Object as Obj
class Element(Obj.Object):

    def __init__(self, color, shape, position, size,name):
        self.name = name
        super().__init__(color, shape, position, size)

    def IsPermittedPlace(self, terrain):
        if terrain[self.pos[0],self.pos[1]] == self.permitted_place :
            return True
        else:
            return False

class Rock(Element):
    def __init__(self, position):
        super().__init__('gray', 'square', position, 1, 'Rock')

class Flower(Element):
    def __init__(self, color, position):
        super().__init__(color, 'square', position, 1, 'Flower')

    def change_color(self):
        self.color = 'yellow'

class Lotus(Element):

    def __init__(self, position):
        super().__init__('green', 'square', position, 2, 'Lotus')

    def change_color(self):
        self.color = 'yellow'