import Object as Obj
import numpy as np
class Element(Obj.Object): #class Parent for create Elemnts

    def __init__(self, color, shape, position, size,name):
        self.name = name
        super().__init__(color, shape, position, size)



class Rock(Element): #class child for create Rocks

    def __init__(self, position):

        super().__init__('gray', 'square', position, 1, 'Rock')



class Flower(Element): #class child for create Flowers

    def __init__(self, color, position):

        super().__init__(color, 'square', position, 1, 'Flower')


    def change_color(self):
        self.color = 'yellow'



class Lotus(Element): #class child for create Lotus

    def __init__(self, position):

        super().__init__('green', 'square', position, 1, 'Lotus')


class Rain(Element): #class child for create Rain

    def __init__(self, position):

        super().__init__('blue', 'square', position, 1, 'rain')


