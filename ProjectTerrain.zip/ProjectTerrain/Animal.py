import Object as Obj
import random
class Animal(Obj.Object): #class parent for create Animals

    def __init__(self,time_live,enviroment,name,movements,color,shape,position,size):

        super().__init__(color,shape,position,size)
        self.time_live = time_live
        self.enviroment = enviroment
        self.name = name
        self.movements = movements


    def move(self): #Move animal to random position

        pos = random.choice(self.movements)
        return (self.pos[0]+pos[0],self.pos[1]+pos[1])
    

    def change_age(self): #Change animal age

        self.time_live = self.time_live-1
    


class Fish(Animal): #class child for create Fish
    
    def __init__(self,position,color,name):

        self.movements_live = [(1,0),(1,0),(-1,0),(-1,0),(0,1),(0,-1)]
        super().__init__(20,0,name,self.movements_live,color,'square',position,0.6)
        

    def goal(self):  #Fish goal: 50% probability the fish up each 3 cicles
            if  self.pos[1] % 3 == 0:
                self.movements = [(1,0),(1,0),(-1,0),(-1,0),(0,1),(0,-1),(0,1),(0,1),(0,1),(0,1)] #50% probability the fish up
            else:
                self.movements = self.movements_live[:]



class Ant(Animal): #class child for create Ant
    
    def __init__(self,position,name):

        self.movements_live = [(1,0),(0,1),(-1,0),(0,-1),(1,0),(0,1)]
        super().__init__(20,8,name,self.movements_live,'brown','circle',position,0.5)

    
    def goal(self):# Ant goal: Can dig rock when time_live > 5
            if  self.time_live > 5: # Can dig rock the first 6 cycles
                return True
            else:
                return False



class Bfly(Animal): #class child for create Bfly
    
    def __init__(self,position,color,name):

        self.movements_live = [(1,0),(0,1),(-1,0),(0,-1),(1,1),(-1,-1),(-1,1),(1,-1)]
        super().__init__(20,1,name,self.movements_live,color,'circle',position,1)
        
    
    def goal(self,flower): #Bfly goal: will always be close on to the flower
            
            x = flower.pos[0]-self.pos[0]
            y = flower.pos[1]-self.pos[1]

            if x != 0   and y!= 0 and flower.color != 'yellow':
                if x > 0 :  #60% probability of be close on to the flower
                        self.movements = [(2,1),(2,1),(1,1),(1,-1),(-1,1)]
                else :
                        self.movements = [(-2,1),(-2,1),(-1,1),(-1,-1),(1,1)]
            else:

                self.movements = self.movements_live[:]



class Frog(Animal): #class child for create Frog
    
    def __init__(self,position,lotus,name):

        self.movements_live = lotus
        super().__init__(30,1,name,self.movements_live,'brown','circle',position,1)
    

    def goal(self): # Frog goal: jump to lotus

            if self.time_live % 2 == 1: # jump
                self.movements= [(self.pos[0],self.pos[1]-8)]
            else : # choose lotus
                self.movements = self.movements_live[:]
    
    
    def move(self): #Move random position

        pos = random.choice(self.movements)
        return pos