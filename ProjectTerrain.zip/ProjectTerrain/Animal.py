import Object as Obj
import Element as El
import random
import matplotlib.pyplot as plt
class Animal(Obj.Object):

    def __init__(self,time_live,enviroment,name,movements,color,shape,position,size):
        super().__init__(color,shape,position,size)
        self.time_live = time_live
        self.enviroment = enviroment
        self.name = name
        self.movements = movements
    
    def discount_age(self):
        self.time_live = self.time_live -1

    def move(self):
        return  random.choice(self.movements)
    

class Fish(Animal):
    
    def __init__(self,position,color,name):
        self.movements_live = [(1,0),(1,0),(-1,0),(-1,0),(0,1),(0,-1)]
        self.movements_dead = [(0,-1)]
        super().__init__(20,0,name,self.movements_live,color,'square',position,1)
        
    def change_movements_dead(self):
        self.movements = self.movements_dead
    
    def objetive(self):  #50% probability the fish up each 3 cicles 
        if  self.pos[1] % 3 == 0:
            self.movements = self.movements.append((0,1),(0,1),(0,1),(0,1)) #50% probability the fish up
        else: 
            self.movements = self.movements_live

class Ant(Animal):
    
    def __init__(self,position,name):
        self.movements_live = [(1,0),(0,1),(-1,0),(0,-1)]
        self.movements_dead = [(0,0)]
        super().__init__(10,8,name,self.movements_live,'brown','circle',position,1)
        
    def change_movements_dead(self):
        self.movements = self.movements_dead
    
    def objetive(self):# Can dig rock the first 6 cycles 
        if  self.time_live > 6:
            dig_rock=True # Can dig rock the first 6 cycles 
        return dig_rock
    

class Bfly(Animal):
    
    def __init__(self,position,color,name):
        self.movements_live = [(1,0),(0,1),(-1,0),(0,-1),(1,1),(-1,-1),(-1,1),(1,-1)]
        self.movements_dead = [(0,-1)]
        super().__init__(8,1,name,self.movements_live,color,'circle',position,1)
        
    def change_movements_dead(self):
        self.movements = self.movements_dead
    
    def objetive(self,flower): #will always be close on to the flower
        if self.time_live > 0:
            x = flower[0]-self.pos[0]
            y = flower[1]-self.pos[1]
            if x != 0 &  y != 0 & flower.color != 'yellow': 
                if x > 0 :  #66% probability of be close on to the flower
                    if y > 0:
                        self.movements = [(1,1),(1,1),(-1,1)] 
                    else :
                        self.movements = [(1,-1),(1,-1),(-1,-1)]
                        
                else : 
                    if y > 0:
                        self.movements = [(-1,1),(-1,1),(1,1)]
                    else :
                        self.movements = [(-1,-1),(-1,-1),(1,-1)]
            else:
                self.movements = self.movements_live
    
    
class Frog(Animal):
    
    def __init__(self,position,lotus,name):
        self.lotus =  lotus
        self.movements_live = []
        self.movements_dead = [(0,0)]
        super().__init__(50,4,'Frog',self.movements_live,'brown','circle',position,1)
        
    def change_movements_dead(self):
        self.movements = self.movements_dead
    
    def objetive(self,lotus): # jump to lotus
        if  self.time_live > 0   :
            dig_rock=True # Can dig rock the first 2 cycles \
            if self.movements == 50 : #star position
                self.movements = [(0,0)] 
            elif self.time_live % 2 == 1 : # jump
                self.movements_live = [(0,4)]
            else : # choose lotus
                self.movements_live = [lotus]
           


    