import math
class Interaction:
    

    def __init__(self, animals, elements, terrain,rain):
        self.animals = animals
        self.elements = elements
        self.animals_dead = []
        self.terrain = terrain
        self.rain = rain


    def drow_all(self,ax,is_rain):
        print('Info: Drow all animals and elements')
        for j in self.animals:
            j.drow(ax)
            ax.annotate(text=str(j.name),xy=(j.pos[0],j.pos[1]+1),ha='center',size='x-small')
        for j in self.elements:
            j.drow(ax)
        for j in self.animals_dead:
            j.drow(ax)
            ax.annotate(text=str(j.name),xy=(j.pos[0],j.pos[1]+1),ha='center',size='x-small')
        
        if is_rain == False:
            self.move_all()
        else:
            for j in self.rain:
                j.drow(ax)
            

    
    def move_all(self): #Move all animals to new position

        print('Info: move all animals')
        self.animals_dead = [] #Empty the animals_dead list
        self.dead() # Initialize the animals_dead list

        animals = [] #Initialize a animals pivot list

        for i in self.animals:
            i.pos = self.move(i) # Move the i animal to new position

            for j in animals: # evaluate and change animals in same place
                if i.pos == j.pos:
                    self.same_place_animals(i, j) #Change the i animal to new position
            
            for j in self.elements: # evaluate and change animals and elements in same place
                if i.pos == j.pos:
                    self.same_place_animal_elements(i, j)

            for j in self.animals_dead: # evaluate and change animals and dead animals in same place
                if i.pos == j.pos:
                    self.same_place_animal_dead(j) #Change the i animal to new position

            animals.append(i) # Save animal i to animal pivot list


    def eat(self, obj1, obj2): #Evaluate the eat interaction between two objects

        if type(obj1).__name__ == 'Bfly' and type(obj2).__name__ == 'Flower':
            obj2.change_color() #Change the flower color to yellow

        if type(obj1).__name__ == 'Frog' and type(obj2).__name__ == 'Bfly':
            self.animals.remove(obj2) #Delete the Bfly


    def dig(self, obj1, obj2): #Evaluate the dig interaction between rock and ant

        if(obj1.goal()): #If the age of ant is > to certain number can remove rock
            self.elements.remove(obj2)
        else: #If the age of ant is <= to certain number cannot remove rock and dodge the rock
            while obj1.pos == obj2.pos:
                obj1.pos = obj1.move()


    def dead(self): # See the age of all animals and evaluate ones is dead

        for animal in self.animals:
            if animal.time_live == 0: #if animals is dead change color to black, remove the animals list and add to animal_dead list
                animal.color = 'black'
                self.animals.remove(animal)
                self.animals_dead.append(animal)
            else:
                animal.change_age() #if animal isn't dead change actual age


    def move(self,ani): #Evaluate the move of animal and move

        if type(ani).__name__ == 'Bfly' : #if animal is Bfly analyze its goals
            flowers = self.find_element('Flower') #Find flowers
            flower = self.closest_element(flowers, ani) #Find the flower closer to bfly
            ani.goal(flower) #Give the flower objetve to bfly
        else:
            ani.goal() #Evaluate the animal's goals

        newPos = ani.move() #New position

        try: #Evaluate the new position is in terrain array 

            if type(ani).__name__ == 'Frog' : #if the animal is frog do nothing
                pass
            elif type(ani).__name__ == 'Ant' : #When the animal is ant, it evaluates its environment and it digs a way
                if self.terrain[newPos[1],newPos[0]] != ani.enviroment:
                    if self.terrain[newPos[1],newPos[0]] != 10:
                        newPos = ani.pos
                else:
                    self.terrain[newPos[1],newPos[0]] = 10
            elif self.terrain[newPos[1],newPos[0]] != ani.enviroment: #Evaluate if new position is animal environment
                newPos = ani.pos

            return newPos
                
        except  IndexError : #If new position is outside terrain array, animal stays in same position

            newPos = ani.pos

        return newPos
        
    
    def same_place_animals(self,obj1, obj2): #Change the position of two animals with the same, or one animal eat the other

        if type(obj1).__name__ == 'Frog' and type(obj2).__name__ == 'Bfly':
            self.eat(obj1,obj2)
        else:
            self.same(obj1,obj2)


    def same_place_animal_elements(self, obj1, obj2):#Change the position of animals with respect element, animal dig element or animal eat element

        if type(obj1).__name__ == 'Bfly' and type(obj2).__name__ == 'Flower':
            self.eat(obj1, obj2)
        elif type(obj1).__name__ == 'Ant' and type(obj2).__name__ == 'Rock':
            self.dig(obj1, obj2)
        elif type(obj1).__name__ == 'Frog' and type(obj2).__name__ == 'Lotus':
            pass
        else:
            while obj1.pos == obj2.pos:
                obj1.pos = self.move(obj1)


    def same_place_animal_dead(self,ani_dead): #Change the position of animals with respect dead animal
        
        self.animals_dead.remove(ani_dead)


    def same(self, obj1, obj2): #Change the position of two objects at the same location

        while obj1.pos == obj2.pos:
            obj1.pos = obj1.move()


    def find_element(self, name_element): #Find element for type

        elements = []
        for j in self.elements:
            if  type(j).__name__ == name_element :
                elements.append(j)
        return elements


    def closest_element(self,elemnts, animal) : #Evaluate closest element
        
        distance = 1000
        element = ()
        for i in elemnts:
            dist = math.sqrt((i.pos[0]-animal.pos[0])**2 +(i.pos[1]-animal.pos[1])**2 )
            if distance > dist:
                element = i
                distance = dist
        return element
                
    

