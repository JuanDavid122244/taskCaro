import Animal as al
import Element as et
import Terrain as tn
import math
class Interaction:
    animals_dead = []

    def __init__(self, animals, elements,terrain):
        self.animals = animals
        self.elements = elements
        self.terrain = terrain

    def move_all(self):
        for i in self.animals:
            i.loc = self.move(i)

        animals = self.animals
        for i in self.animals:
            animals.remove(i) 
            for j in animals: # evaluate and change animals in same place
                while i.loc == j.loc:
                    self.same_place_animals(i, j)
            
            for j in self.elements: # evaluate and change animals and elements in same place
                while i.loc == j.loc:
                    self.same_place_animal_elements(i, j)
            
            for j in self.animals_dead: # evaluate and change animals and dead animals in same place
                while i.loc == j.loc:
                    self.same_place_animal_dead(i, j)
     

                  

    def eat(self, obj1, obj2):
        if type(obj1).__name__ == 'Bfly' & type(obj2).__name__ == 'Flower':
            obj2.change_color()
        if type(obj1).__name__ == 'Frog' & type(obj2).__name__ == 'Bfly':
            self.animals.remove(obj2)

    def dig(self, obj1, obj2):
        if(obj1.objetive()):
            self.elements.remove(obj2)
        else:
            while obj1.loc == obj2.loc:
                obj1.loc = obj1.move()

    def dead(self):
        for i in self.animals:
            if i.time_live == 0:
                i.change_movements_dead()
                i.color = 'black'
                self.animals.remove(i)
                self.animals_dead.append(i)

    def move(self,ani):
        newPos = ()           
        if type(ani).__name__ == 'Frog' : 
            lotus = self.find_element('Lotus')   
            ani.objetive(lotus)
            newPos=ani.move()
        elif type(ani).__name__ == 'Bfly' : 
            flowers = self.find_element('flowers')
            flower = self.closest_element(flowers, ani)   
            ani.objetive(flower)
            newPos=ani.move()
        else:
            ani.objetive() 
            newPos=ani.move()

        if self.limits_animals(ani):
            return newPos
        else:           
            return self.move(ani)
    
    def same_place_animals(self,obj1, obj2):
        if type(obj1).__name__ == 'Frog' & type(obj2).__name__ == 'Bfly':
            self.eat(obj1,obj2)
        else:
            self.same(obj1,obj2)
 
    def same_place_animal_elements(self, obj1, obj2):  
        if type(obj1).__name__ == 'Bfly' & type(obj2).__name__ == 'Flower':
            self.eat(obj1, obj2)
        elif type(obj1).__name__ == 'Ant' & type(obj2).__name__ == 'Rock':
            self.dig(obj1, obj2)
        else:
            while obj1.pos == obj2.pos:
                obj1.loc = self.move(obj1)

    def same_place_animal_dead(self,obj1,ani_dead):
        self.animals_dead.remove(ani_dead)

    def limits_animals(self, obj):
        if self.terrain[obj.loc[0],obj.loc[1]] != obj.enviroment:
            return True
        else: 
            return False

    def same(self, obj1, obj2):
        while obj1.pos == obj2.pos:
            obj1.loc = self.move(obj1)
            obj2.loc = self.move(obj2)

    def find_element(self, name_element):
        elements = []
        for j in self.elements: #find element
            if  type(j).__name__ == elements :  
                elements.append(j.pos)
        return elements

    def closest_element(self,elemnts, animal) :
        distance = 1000
        element = ()
        for i in elemnts:
            dist = math.sqrt((i.pos[0]-animal.pos[0])**2 +(i.pos[1]-animal.pos[1])**2 )
            if distance > dist:
                element = i
                distance = dist
        return element
                
    

