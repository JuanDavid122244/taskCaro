import matplotlib.pyplot as plt
class Object:

    def __init__(self,color,shape,position,size):
        self.color = color
        self.shape = shape
        self.pos = position
        self.size = size

    def drow(self,ax):
        if self.shape == 'square':
            x =[self.pos[0], self.pos[0]+self.size, self.pos[0]+self.size, self.pos[0], self.pos[0]]
            y =[self.pos[1], self.pos[1], self.pos[1]+self.size, self.pos[1]+self.size, self.pos[1]]
            fig = plt.fill(x, y, color = self.color)
        elif self.shape == 'circle':
            fig = plt.Circle(self.pos, self.size, color = self.color)
            ax.add_patch(fig)
        else:
            print('Error: Only shape Object square and circle')
            plt.wait()

# test class
#s=Object('blue','circle',(2,2),1)
#plt.figure(figsize=(8,8))
#ax = plt.axes()
#ax.plot([1,10],[1,10])
#s.drow(ax)
#n=Object('red','square',(3,3),2)
#n.drow(ax)
#plt.show()
