def sor(a, b):
    x = a+b 
    print(x<10)
    print(x>20)
    print(x<10 or x>20)
    if x<10 or x>20:
        return x
    else:
        return 20
    

print(sor(3,4))

if !vacation:
    if day == 0 or day == 6:
        return '7:00'
    else 


def fun(n, bol):
    if bol != True:
        if n>=1 or n<=10:
            return True
    if n<= 1 or n>= 10:
        return True
    return False